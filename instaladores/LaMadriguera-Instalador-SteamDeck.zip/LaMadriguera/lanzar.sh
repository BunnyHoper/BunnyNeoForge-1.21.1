#!/bin/sh
# Lo mismo que «Lanzar» desde una terminal
cd "$(dirname "$0")" && exec ./LaMadriguera-Instalador "$@"
