#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

layout(location = 4) in float interpFactor;
layout(location = 5) in vec2 texCoordNext;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    if (color.a < 0.1) {
        discard;
    }

    if (color.r > 0.988 && color.r < 0.989
        && color.g > 0.988 && color.g < 0.989
        && color.b > 0.4 && color.b < 0.5) {
        color = vec4(0.404, 0.365, 0.286, color.a);
    }
    if (color.r > 0.2479 && color.r < 0.251
        && color.g > 0.2479 && color.g < 0.251
        && color.b > 0.2479 && color.b < 0.251) {
        color = vec4(0.133333, 0.133333, 0.133333, color.a);
    }

    if (interpFactor > 0.0) {
        #ifdef IS_GRAYSCALE
        vec4 nextColor = texture(Sampler0, texCoordNext).rrrr;
        #else
        vec4 nextColor = texture(Sampler0, texCoordNext);
        #endif
        vec4 color2 = nextColor * vertexColor * ColorModulator;
        color = mix(color, color2, interpFactor);
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
