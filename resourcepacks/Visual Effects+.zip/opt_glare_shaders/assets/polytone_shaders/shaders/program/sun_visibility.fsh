#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D InDepth;
uniform sampler2D History;
uniform mat4 PolyProjMat;
uniform mat4 PolyModelViewMat;
uniform float PolySunAngle;
uniform float PolyDayTime;
uniform float PolyDeltaTime;

in vec2 texCoord;
out vec4 fragColor;

// Fade duration in game ticks. 20 ticks = 1 second.
const float FADE_IN_TICKS = 12.0;
const float FADE_OUT_TICKS = 12.0;

const float SKY_DEPTH_MIN = 0.9997;
const float SKY_DEPTH_MAX = 0.999995;
const float VIS_RADIUS_PX = 96.0;
const float SUN_DISC_RADIUS_PX = 96.0;
const float EDGE_PRESERVE = 1.0;

float sampleSkyVisibility(vec2 uv) {
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        return 0.0;
    }

    float depth = texture(InDepth, uv).r;
    return smoothstep(SKY_DEPTH_MIN, SKY_DEPTH_MAX, depth);
}

vec2 getSunScreenUV(float angle, out bool isBehind) {
    vec3 sunDirWorld = normalize(vec3(cos(angle), sin(angle), 0.0));
    vec3 camPos = vec3(PolyModelViewMat[3]);
    vec3 lightPosWorld = camPos - sunDirWorld * 1000.0;
    vec4 lightClip = PolyProjMat * (PolyModelViewMat * vec4(lightPosWorld, 1.0));

    isBehind = lightClip.w <= 0.0;
    if (isBehind) {
        return vec2(-1.0);
    }

    return (lightClip.xy / lightClip.w) * 0.5 + 0.5;
}

float getSunWeight(float angle) {
    const float PI = 3.14159;
    float t = mod(angle + PI, 2.0 * PI);

    const float SUNSET_START = PI - 0.10;
    const float SUNSET_END = PI + 0.18;
    const float SUNRISE_START = 2.0 * PI - 0.42;
    const float SUNRISE_END = 2.0 * PI - 0.06;

    if (t < SUNSET_START) {
        return 1.0;
    }
    if (t < SUNSET_END) {
        return 1.0 - smoothstep(SUNSET_START, SUNSET_END, t);
    }
    if (t < SUNRISE_START) {
        return 0.0;
    }
    if (t < SUNRISE_END) {
        return smoothstep(SUNRISE_START, SUNRISE_END, t);
    }
    return 1.0;
}

float getCurrentVisibility() {
    if (getSunWeight(PolySunAngle) <= 0.0) {
        return 0.0;
    }

    bool isBehind;
    vec2 lightUV = getSunScreenUV(PolySunAngle, isBehind);
    if (isBehind || lightUV.x < 0.0 || lightUV.x > 1.0 || lightUV.y < 0.0 || lightUV.y > 1.0) {
        return 0.0;
    }

    vec2 px = 1.0 / vec2(textureSize(InDepth, 0));
    vec2 innerR = px * VIS_RADIUS_PX;

    float centerSum = sampleSkyVisibility(lightUV) * 2.0;
    float centerW = 2.0;

    centerSum += sampleSkyVisibility(lightUV + vec2( innerR.x, 0.0)) * 1.5;
    centerSum += sampleSkyVisibility(lightUV + vec2(-innerR.x, 0.0)) * 1.5;
    centerSum += sampleSkyVisibility(lightUV + vec2(0.0,  innerR.y)) * 1.5;
    centerSum += sampleSkyVisibility(lightUV + vec2(0.0, -innerR.y)) * 1.5;
    centerW += 6.0;

    centerSum += sampleSkyVisibility(lightUV + vec2( innerR.x,  innerR.y));
    centerSum += sampleSkyVisibility(lightUV + vec2(-innerR.x,  innerR.y));
    centerSum += sampleSkyVisibility(lightUV + vec2( innerR.x, -innerR.y));
    centerSum += sampleSkyVisibility(lightUV + vec2(-innerR.x, -innerR.y));
    centerW += 4.0;

    float avgVisible = smoothstep(0.18, 0.82, centerSum / centerW);

    vec2 discR = px * SUN_DISC_RADIUS_PX;
    float maxVisible = sampleSkyVisibility(lightUV);
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2( discR.x, 0.0)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2(-discR.x, 0.0)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2(0.0,  discR.y)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2(0.0, -discR.y)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2( discR.x * 0.7,  discR.y * 0.7)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2(-discR.x * 0.7,  discR.y * 0.7)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2( discR.x * 0.7, -discR.y * 0.7)));
    maxVisible = max(maxVisible, sampleSkyVisibility(lightUV + vec2(-discR.x * 0.7, -discR.y * 0.7)));
    maxVisible = smoothstep(0.08, 0.70, maxVisible);

    return clamp(max(
        avgVisible,
        maxVisible * EDGE_PRESERVE + avgVisible * (1.0 - EDGE_PRESERVE)
    ), 0.0, 1.0);
}

void main() {
    vec4 history = texture(History, vec2(0.5));
    float previous = history.a < 0.5 ? 0.0 : clamp(history.r, 0.0, 1.0);
    float current = getCurrentVisibility();

    float duration = current > previous ? FADE_IN_TICKS : FADE_OUT_TICKS;
    float frameDelta = clamp(PolyDeltaTime, 0.0, 5.0);
    float maxStep = frameDelta / max(duration, 0.0001);
    float filtered = previous + clamp(current - previous, -maxStep, maxStep);

    fragColor = vec4(vec3(clamp(filtered, 0.0, 1.0)), 1.0);
}
