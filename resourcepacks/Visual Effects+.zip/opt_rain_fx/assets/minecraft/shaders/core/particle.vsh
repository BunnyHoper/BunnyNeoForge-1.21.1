#version 150

#moj_import <fog.glsl>
#moj_import <rain_utils.glsl>

in vec3 Position;
in vec2 UV0;
in vec4 Color;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;
flat out int isRain;

mat4 mat_xform() {
    float r = radians(20.0);
    vec2 scale = vec2(1.0, 1.6);
    vec3 offset = vec3(0.0, 2.5, 0.0);
    mat4 scaleMat = mat4(scale.x,0,0,0, 0,scale.y,0,0, 0,0,1,0, 0,0,0,1);
    mat4 rotMat = mat4(cos(r),sin(r),0,0, -sin(r),cos(r),0,0, 0,0,1,0, 0,0,0,1);
    mat4 posMat = mat4(1,0,0,0, 0,1,0,0, 0,0,1,0, offset.x,offset.y,offset.z,1);
    return posMat * rotMat * scaleMat;
}

vec2 rain_tail_compensation(vec2 uv) {
    float r = radians(20.0);
    return normalize(vec2(sin(r), -cos(r))) * 0.08 * uv.y;
}

void main() {
    texCoord0 = UV0;
    float alpha = textureLod(Sampler0, texCoord0, 0.0).a * 255.0;
    vec3 fogPos = Position;
    if (check_alpha(alpha, 97.0)) {
        vec4 transformed = mat_xform() * vec4(Position, 1.0);
        transformed.xy += rain_tail_compensation(UV0);
        gl_Position = ProjMat * ModelViewMat * transformed;
        fogPos = transformed.xyz;
        isRain = 1;
    } else {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
        isRain = 0;
    }
    vertexDistance = fog_distance(fogPos, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
}
