#version 150

#moj_import <fog.glsl>

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform vec2 ScreenSize;

in float vertexDistance;
flat in float skyPass;

out vec4 fragColor;

// ---------- HAZE CONFIG ----------

const float HAZE_BRIGHTNESS_FULL = 0.45;
const float HAZE_BRIGHTNESS_MIN = 0.25;
const float HAZE_NIGHT_MULTIPLIER = 1.0;

const float HAZE_START = -0.16;
const float HAZE_END = 0.42;
const float HAZE_OPACITY = 1.35;
const float HAZE_POWER = 1.0;

const float HAZE_WHITE_OVERLAY = 0.9;
const float HAZE_FOG_MIX = 0.5;

// ---------- DOME CONFIG ----------

const vec3 DOME_COLOR = vec3(0.0, 0.0, 0.0);
const float DOME_STRENGTH = 0.12;
const float DOME_START = 0.42;
const float DOME_END = 1.0;
const float DOME_POWER = 1.45;

// ---------- NIGHT OVERLAY CONFIG ----------

const vec3 NIGHT_OVERLAY_COLOR = vec3(0.1059, 0.2196, 0.4549);
const float NIGHT_OVERLAY_STRENGTH = 0.35;
const float NIGHT_OVERLAY_FADE_START = 0.08;
const float NIGHT_OVERLAY_FADE_END = 0.24;
const float NIGHT_OVERLAY_POWER = 1.0;

// 0 = normal mix, 1 = Photoshop-like Overlay.
const int NIGHT_OVERLAY_BLEND_MODE = 0;

// ---------- STARS CONFIG ----------

const float STAR_STRENGTH = 1.15;
const float STAR_DENSITY = 64.0;
const float STAR_SIZE = 0.1;

const float STAR_HORIZON_START = -0.2;
const float STAR_HORIZON_END = 0.08;
const float STAR_DAY_FADE_START = 0.08;
const float STAR_DAY_FADE_END = 0.24;

vec3 blendOverlay(vec3 base, vec3 blend) {
    return mix(
        2.0 * base * blend,
        1.0 - 2.0 * (1.0 - base) * (1.0 - blend),
        step(vec3(0.5), base)
    );
}

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
    float n = hash12(p);
    return vec2(n, hash12(p + n + 19.19));
}

vec3 getViewDirection() {
    vec2 pos = gl_FragCoord.xy / ScreenSize;
    pos = pos * 2.0 - 1.0;

    vec4 castPos = inverse(ProjMat) * vec4(pos, 1.0, 1.0);
    castPos = normalize(castPos);

    return normalize(castPos.xyz * mat3(ModelViewMat));
}

float getStars(vec3 viewDir) {
    vec3 p = normalize(viewDir);
    vec2 uv;

    if (abs(p.y) > 0.65) {
        uv = p.xz / max(abs(p.y), 0.001);
    } else if (abs(p.x) > abs(p.z)) {
        uv = p.zy / max(abs(p.x), 0.001);
    } else {
        uv = p.xy / max(abs(p.z), 0.001);
    }

    vec2 gridUV = uv * STAR_DENSITY;
    vec2 cell = floor(gridUV);
    vec2 local = fract(gridUV);

    vec2 starPos = hash22(cell);
    float starExists = step(0.965, hash12(cell + 7.13));

    vec2 delta = abs(local - starPos);
    float squareDist = max(delta.x, delta.y);
    float aa = clamp(max(fwidth(local.x), fwidth(local.y)), 0.001, 0.018);

    float core = 1.0 - smoothstep(STAR_SIZE, STAR_SIZE + aa, squareDist);
    float brightness = mix(0.35, 1.0, hash12(cell + 23.71));

    return clamp(core * starExists * brightness, 0.0, 1.0);
}

void main() {
    // Preserve the vanilla behaviour for the non-sky calls that share this
    // shader in Minecraft 1.21.1.
    if (skyPass < 0.5) {
        fragColor = linear_fog(
            ColorModulator,
            vertexDistance,
            FogStart,
            FogEnd,
            FogColor
        );
        return;
    }

    vec3 finalColor = ColorModulator.rgb;
    vec3 viewDir = getViewDirection();

    // Haze colour.
    vec3 whiteOverlayColor = mix(
        vec3(0.5),
        vec3(1.0),
        HAZE_WHITE_OVERLAY
    );
    vec3 hazeOverlayColor = blendOverlay(FogColor.rgb, whiteOverlayColor);
    vec3 hazeColor = mix(hazeOverlayColor, FogColor.rgb, HAZE_FOG_MIX);

    // Horizon haze.
    float hazeMask = 1.0 - smoothstep(HAZE_START, HAZE_END, viewDir.y);
    hazeMask = pow(clamp(hazeMask, 0.0, 1.0), HAZE_POWER);

    float skyBrightnessForHaze = dot(
        ColorModulator.rgb,
        vec3(0.2126, 0.7152, 0.0722)
    );
    float hazeBrightnessMask = smoothstep(
        HAZE_BRIGHTNESS_MIN,
        HAZE_BRIGHTNESS_FULL,
        skyBrightnessForHaze
    );
    float hazeBrightnessMultiplier = mix(
        HAZE_NIGHT_MULTIPLIER,
        1.0,
        hazeBrightnessMask
    );

    hazeMask *= HAZE_OPACITY * hazeBrightnessMultiplier;
    finalColor = mix(finalColor, hazeColor, clamp(hazeMask, 0.0, 1.0));

    // Dark upper dome.
    float domeMask = smoothstep(DOME_START, DOME_END, viewDir.y);
    domeMask = pow(clamp(domeMask, 0.0, 1.0), DOME_POWER);
    finalColor = mix(finalColor, DOME_COLOR, domeMask * DOME_STRENGTH);

    // Night tint.
    float skyBrightnessForNightOverlay = dot(
        ColorModulator.rgb,
        vec3(0.2126, 0.7152, 0.0722)
    );
    float nightOverlayMask = 1.0 - smoothstep(
        NIGHT_OVERLAY_FADE_START,
        NIGHT_OVERLAY_FADE_END,
        skyBrightnessForNightOverlay
    );
    nightOverlayMask = pow(
        clamp(nightOverlayMask, 0.0, 1.0),
        NIGHT_OVERLAY_POWER
    );

    if (NIGHT_OVERLAY_BLEND_MODE == 1) {
        vec3 overlayColor = blendOverlay(finalColor, NIGHT_OVERLAY_COLOR);
        finalColor = mix(
            finalColor,
            overlayColor,
            nightOverlayMask * NIGHT_OVERLAY_STRENGTH
        );
    } else {
        finalColor = mix(
            finalColor,
            NIGHT_OVERLAY_COLOR,
            nightOverlayMask * NIGHT_OVERLAY_STRENGTH
        );
    }

    // Procedural square stars.
    float skyBrightness = dot(
        ColorModulator.rgb,
        vec3(0.2126, 0.7152, 0.0722)
    );
    float nightMask = 1.0 - smoothstep(
        STAR_DAY_FADE_START,
        STAR_DAY_FADE_END,
        skyBrightness
    );
    float starHorizonMask = smoothstep(
        STAR_HORIZON_START,
        STAR_HORIZON_END,
        viewDir.y
    );

    float stars = getStars(viewDir);
    stars *= nightMask * starHorizonMask * STAR_STRENGTH;
    finalColor += vec3(stars);

    fragColor = vec4(finalColor, 1.0);
}
