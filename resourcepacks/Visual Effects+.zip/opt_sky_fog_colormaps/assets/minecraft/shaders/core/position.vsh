#version 150

#moj_import <fog.glsl>

in vec3 Position;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
flat out float skyPass;

void main() {
    // The 1.21.1 sky uses the shared position shader. Perspective projection
    // identifies the world sky pass; orthographic calls are UI/text highlights.
    skyPass = abs(ProjMat[3][3]) < 0.5 ? 1.0 : 0.0;

    if (skyPass > 0.5) {
        // Expand the old sky mesh into a full-screen surface. View rotation is
        // reconstructed in the fragment shader, as in NightSkyShader 1.20.5+.
        vec4 pos = ProjMat * vec4(Position, 1.0);
        pos.y = -pos.z;
        gl_Position = pos;
    } else {
        gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    }

    vertexDistance = fog_distance(Position, FogShape);
}
