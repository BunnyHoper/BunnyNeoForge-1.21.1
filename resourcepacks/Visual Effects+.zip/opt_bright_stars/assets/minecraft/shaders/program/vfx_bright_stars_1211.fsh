#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D InDepth;
uniform vec2 InSize;
uniform vec2 OutSize;
uniform mat4 PolyProjMat;

in vec2 texCoord;
out vec4 fragColor;

float luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

void main() {
    vec4 base = texture(DiffuseSampler, texCoord);
    float depth = texture(InDepth, texCoord).r;
    float projScale = clamp(abs(PolyProjMat[0][0]), 0.25, 4.0);
    vec2 px = vec2(1.0) / (InSize * sqrt(projScale));

    float center = luminance(base.rgb);
    float around = 0.25 * (
        luminance(texture(DiffuseSampler, texCoord + vec2(px.x, 0.0)).rgb) +
        luminance(texture(DiffuseSampler, texCoord - vec2(px.x, 0.0)).rgb) +
        luminance(texture(DiffuseSampler, texCoord + vec2(0.0, px.y)).rgb) +
        luminance(texture(DiffuseSampler, texCoord - vec2(0.0, px.y)).rgb)
    );

    float skyMask = smoothstep(0.9995, 1.0, depth);
    float nightMask = 1.0 - smoothstep(0.28, 0.65, around);
    float starSignal = smoothstep(0.025, 0.22, center - around * 1.12);
    float boost = skyMask * nightMask * starSignal;
    vec3 brightened = min(base.rgb * vec3(1.5, 1.6, 1.75), vec3(1.0));
    fragColor = vec4(mix(base.rgb, brightened, boost), base.a);
}
