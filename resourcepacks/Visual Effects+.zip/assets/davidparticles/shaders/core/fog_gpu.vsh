#version 150

#moj_import <fog.glsl>
#moj_import <light.glsl>

in vec3 Position;

/* Polytone binds this buffer itself. Do not add it to fog_gpu.json. */
uniform samplerBuffer ParticleData;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Origin;
uniform float Time;
uniform float Gravity;
uniform float Drag;
uniform float SizeEnd;
uniform int UseColorEnd;
uniform vec4 ColorEnd;
uniform vec2 Fade;
uniform float Sway;
uniform float Spin;
uniform float Aspect;
uniform int Billboard;
uniform int Frames;
uniform int RandomSprite;
uniform int AreaCount;
uniform vec3 AreaSize;
uniform int KillBelowHeightmap;
uniform vec4 HeightmapInfo;
uniform float CameraY;

out float vertexDistance;
out vec2 texCoord0;
out vec4 vertexColor;

const float PI = 3.14159265359;
const float TAU = 6.28318530718;

float hash(float seed, float salt) {
    return fract(
        sin(seed * 127.1 + salt * 311.7) *
        43758.5453
    );
}

void hideParticle() {
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    vertexDistance = 0.0;
    texCoord0 = vec2(0.0);
    vertexColor = vec4(0.0);
}

bool getSurfaceRelativeY(
    vec2 relativeXZ,
    out float surfaceRelativeY
) {
    vec2 uv =
        (relativeXZ - HeightmapInfo.xy) /
        HeightmapInfo.z;

    if (
        any(lessThan(uv, vec2(0.0))) ||
        any(greaterThanEqual(uv, vec2(1.0)))
    ) {
        return false;
    }

    ivec2 texelPosition =
        ivec2(uv * HeightmapInfo.z);

    vec4 heightData = texelFetch(
        Sampler1,
        texelPosition,
        0
    );

    float surfaceWorldY =
        HeightmapInfo.w +
        heightData.r * 255.0 +
        heightData.g * 255.0 * 256.0;

    surfaceRelativeY =
        surfaceWorldY - CameraY;

    return true;
}

void main() {
    int quad = gl_VertexID >> 2;
    int corner = gl_VertexID & 3;

    /*
     * In 1.21.1 one particle record occupies four texels.
     * AreaCount quads can share one record.
     */
    int recordId = quad / AreaCount;
    int areaIndex = quad - recordId * AreaCount;

    vec4 data0 = texelFetch(
        ParticleData,
        recordId * 4
    );

    vec4 data1 = texelFetch(
        ParticleData,
        recordId * 4 + 1
    );

    vec4 data2 = texelFetch(
        ParticleData,
        recordId * 4 + 2
    );

    vec4 data3 = texelFetch(
        ParticleData,
        recordId * 4 + 3
    );

    float life = data1.w;
    float age = Time - data1.z;

    if (
        life <= 0.0 ||
        age < 0.0 ||
        age >= life
    ) {
        hideParticle();
        return;
    }

    float lifetimeProgress = age / life;
    float seed =
        data2.x +
        float(areaIndex) * 0.6180339;

    float phase = data3.y * TAU;

    /*
     * Smooth vertical motion equivalent to the 1.21.11 shader.
     */
    float verticalOffset =
        (
            cos(phase) -
            cos(age * 0.04 + phase)
        ) * 0.25;

    const float HEIGHT_ABOVE_SURFACE = 3.0;
    const float MAX_SURFACE_RISE = 4.0;

    vec3 particlePos =
        data0.xyz +
        Origin;

    if (AreaCount > 1) {
        particlePos +=
            (
                vec3(
                    hash(seed, 5.0),
                    hash(seed, 6.0),
                    hash(seed, 7.0)
                ) -
                0.5
            ) *
            AreaSize;
    }

    float emitterRelativeY =
        particlePos.y;

    float surfaceRelativeY;

    if (
        !getSurfaceRelativeY(
            particlePos.xz,
            surfaceRelativeY
        )
    ) {
        hideParticle();
        return;
    }

    /*
     * Reject tree tops, roofs and other surfaces that are
     * too high above the emitter's original height.
     */
    if (
        surfaceRelativeY >
        emitterRelativeY + MAX_SURFACE_RISE
    ) {
        hideParticle();
        return;
    }

    particlePos.y =
        surfaceRelativeY +
        HEIGHT_ABOVE_SURFACE +
        verticalOffset;

    float distanceSquared =
        dot(particlePos, particlePos);

    if (distanceSquared > 900.0) {
        hideParticle();
        return;
    }

    float distanceToCamera =
        sqrt(distanceSquared);

    float innerDistanceFade = clamp(
        (distanceSquared - 25.0) / 100.0,
        0.0,
        1.0
    );

    float outerDistanceFade = clamp(
        (25.0 - distanceToCamera) / 5.0,
        0.0,
        1.0
    );

    float lifetimeFade = max(
        sin(PI * lifetimeProgress),
        0.0
    );

    /* Decode alpha and RGB from the packed 1.21.1 record. */
    float lightAlpha = data2.y;
    float packedRgb = data2.z;

    float alpha8 =
        floor(lightAlpha / 65536.0);

    float packedLight =
        lightAlpha - alpha8 * 65536.0;

    float blue8 =
        floor(packedRgb / 65536.0);

    float green8 = floor(
        (
            packedRgb -
            blue8 * 65536.0
        ) /
        256.0
    );

    float red8 =
        packedRgb -
        blue8 * 65536.0 -
        green8 * 256.0;

    vec4 particleColor =
        vec4(
            red8,
            green8,
            blue8,
            alpha8
        ) /
        255.0;

    float finalAlpha =
        particleColor.a *
        lifetimeFade *
        innerDistanceFade *
        outerDistanceFade;

    vec3 right = vec3(
        ModelViewMat[0][0],
        ModelViewMat[1][0],
        ModelViewMat[2][0]
    );

    vec3 up = vec3(
        ModelViewMat[0][1],
        ModelViewMat[1][1],
        ModelViewMat[2][1]
    );

    vec2 cornerPosition = vec2(
        corner == 1 || corner == 2
            ? 1.0
            : -1.0,

        corner >= 2
            ? 1.0
            : -1.0
    );

    float roll =
        phase +
        sin(age * 0.025 + phase) * 0.25;

    float rollSin = sin(roll);
    float rollCos = cos(roll);

    cornerPosition = vec2(
        cornerPosition.x * rollCos -
        cornerPosition.y * rollSin,

        cornerPosition.x * rollSin +
        cornerPosition.y * rollCos
    );

    float size = data2.w;

    vec3 renderPosition =
        particlePos +
        right * (cornerPosition.x * size) +
        up * (cornerPosition.y * size * Aspect);

    float frame = RandomSprite == 1
        ? floor(
            hash(seed, 4.0) *
            float(Frames)
        )
        : min(
            floor(
                lifetimeProgress *
                float(Frames)
            ),
            float(Frames - 1)
        );

    float u =
        corner == 1 || corner == 2
            ? 1.0
            : 0.0;

    float v =
        corner >= 2
            ? 0.0
            : 1.0;

    texCoord0 = vec2(
        u,
        (frame + v) / float(Frames)
    );

    ivec2 lightCoordinates = ivec2(
        int(mod(packedLight, 256.0)),
        int(packedLight / 256.0)
    );

    vec4 lightColor =
        minecraft_sample_lightmap(
            Sampler2,
            lightCoordinates
        );

    vertexColor =
        vec4(
            particleColor.rgb,
            finalAlpha
        ) *
        lightColor;

    vertexDistance =
        fog_distance(
            renderPosition,
            FogShape
        );

    gl_Position =
        ProjMat *
        ModelViewMat *
        vec4(renderPosition, 1.0);
}
