#version 150

#moj_import <fog.glsl>
#moj_import <light.glsl>

in vec3 Position;

uniform samplerBuffer ParticleData;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

uniform vec3 Origin;
uniform float Time;
uniform float Gravity;
uniform float Drag;
uniform float SizeEnd;
uniform int UseColorEnd;
uniform vec4 ColorEnd;
uniform vec2 Fade;
uniform float Sway;
uniform float Spin;
uniform float Aspect;
uniform int Billboard;
uniform int Frames;
uniform int RandomSprite;
uniform int AreaCount;
uniform vec3 AreaSize;
uniform int KillBelowHeightmap;
uniform vec4 HeightmapInfo;
uniform float CameraY;

uniform float RainStrength;
uniform float PlayerRelativeX;
uniform float PlayerRelativeZ;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const float SPEED_MULTIPLIER = 2.0;
const int COLLISION_STEPS = 8;

float hash(float seed, float salt) {
    return fract(sin(seed * 127.1 + salt * 311.7) * 43758.5453);
}

vec3 rotateX(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return vec3(p.x, p.y * c - p.z * s, p.y * s + p.z * c);
}

vec3 rotateY(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return vec3(p.x * c + p.z * s, p.y, -p.x * s + p.z * c);
}

vec3 rotateZ(vec3 p, float angle) {
    float s = sin(angle);
    float c = cos(angle);
    return vec3(p.x * c - p.y * s, p.x * s + p.y * c, p.z);
}

void hideParticle() {
    gl_Position = vec4(-2.0, -2.0, -2.0, 1.0);
    vertexDistance = 0.0;
    vertexColor = vec4(0.0);
    texCoord0 = vec2(0.0);
}

bool isBelowSurface(vec3 position) {
    vec2 uv = (position.xz - HeightmapInfo.xy) / HeightmapInfo.z;
    if (any(lessThan(uv, vec2(0.0))) || any(greaterThanEqual(uv, vec2(1.0)))) {
        return false;
    }
    vec4 heightData = texelFetch(Sampler1, ivec2(uv * HeightmapInfo.z), 0);
    float surfaceHeight = HeightmapInfo.w + heightData.r * 255.0 + heightData.g * 255.0 * 256.0;
    return position.y + CameraY <= surfaceHeight;
}

bool pathHitsSurface(vec3 startPosition, vec3 currentPosition) {
    for (int i = 0; i <= COLLISION_STEPS; i++) {
        float pathProgress = float(i) / float(COLLISION_STEPS);
        if (isBelowSurface(mix(startPosition, currentPosition, pathProgress))) {
            return true;
        }
    }
    return false;
}

void main() {
    int quad = gl_VertexID >> 2;
    int corner = gl_VertexID & 3;
    int id = quad / AreaCount;
    int sub = quad - id * AreaCount;

    vec4 a = texelFetch(ParticleData, id * 4);
    vec4 b = texelFetch(ParticleData, id * 4 + 1);
    vec4 c = texelFetch(ParticleData, id * 4 + 2);
    vec4 d = texelFetch(ParticleData, id * 4 + 3);

    float life = b.w;
    float age = Time - b.z;
    if (life <= 0.0 || age < 0.0 || age >= life) {
        hideParticle();
        return;
    }

    float progress = age / life;
    float seed = c.x + float(sub) * 0.6180339;
    float lightAlpha = c.y;
    float rgb = c.z;
    float size0 = c.w;
    float randomValue = d.y;

    vec3 movement = vec3(RainStrength * 0.5, -0.75, randomValue * 0.08 - 0.04) * SPEED_MULTIPLIER;
    vec3 horizontalCentering = vec3(movement.x, 0.0, movement.z) * (life * 0.5);

    vec3 startPosition = a.xyz + Origin - horizontalCentering;
    if (AreaCount > 1) {
        startPosition += (vec3(hash(seed, 5.0), hash(seed, 6.0), hash(seed, 7.0)) - 0.5) * AreaSize;
    }
    vec3 particlePos = startPosition + movement * age;

    if (KillBelowHeightmap == 1 && pathHitsSurface(startPosition, particlePos)) {
        hideParticle();
        return;
    }

    float sideMultiplier = particlePos.x > PlayerRelativeX ? -1.0 : 1.0;
    float xRotation = (particlePos.z < PlayerRelativeZ ? -0.45 : 0.45) * sideMultiplier;
    float yRotation = (particlePos.z < PlayerRelativeZ ? 0.5 : -0.5) * sideMultiplier;
    float zRotation = 0.75;

    vec2 cornerPosition = vec2(
        corner == 1 || corner == 2 ? 1.0 : -1.0,
        corner >= 2 ? 1.0 : -1.0
    );
    float size = SizeEnd < 0.0 ? size0 : mix(size0, SizeEnd, progress);
    vec3 localPosition = vec3(cornerPosition.x * size, cornerPosition.y * size * Aspect, 0.0);
    localPosition = rotateX(rotateY(rotateZ(localPosition, zRotation), yRotation), xRotation);
    vec3 renderPosition = particlePos + localPosition;

    float frame = RandomSprite == 1
        ? floor(hash(seed, 4.0) * float(Frames))
        : min(floor(progress * float(Frames)), float(Frames - 1));
    float u = corner == 1 || corner == 2 ? 1.0 : 0.0;
    float v = corner >= 2 ? 0.0 : 1.0;
    texCoord0 = vec2(u, (frame + v) / float(Frames));

    float fade = 1.0;
    if (Fade.x > 0.0) fade *= smoothstep(0.0, Fade.x, progress);
    if (Fade.y > 0.0) fade *= 1.0 - smoothstep(1.0 - Fade.y, 1.0, progress);

    float alpha8 = floor(lightAlpha / 65536.0);
    float light = lightAlpha - alpha8 * 65536.0;
    float b8 = floor(rgb / 65536.0);
    float g8 = floor((rgb - b8 * 65536.0) / 256.0);
    float r8 = rgb - b8 * 65536.0 - g8 * 256.0;
    vec4 startColor = vec4(r8, g8, b8, alpha8) / 255.0;
    vec4 color = UseColorEnd == 1 ? mix(startColor, ColorEnd, progress) : startColor;
    ivec2 lightCoords = ivec2(int(mod(light, 256.0)), int(light / 256.0));
    vertexColor = color * minecraft_sample_lightmap(Sampler2, lightCoords) * vec4(1.0, 1.0, 1.0, fade);

    vertexDistance = fog_distance(renderPosition, FogShape);
    gl_Position = ProjMat * ModelViewMat * vec4(renderPosition, 1.0);
}
