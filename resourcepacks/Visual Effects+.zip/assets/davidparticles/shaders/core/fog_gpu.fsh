#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform float AlphaCutoff;

in float vertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;

out vec4 fragColor;

const float FOG_WHITE_MIX = 0.25;

void main() {
    vec4 textureColor =
        texture(Sampler0, texCoord0);

    vec4 particleFogColor = vec4(
        mix(
            FogColor.rgb,
            vec3(1.0),
            FOG_WHITE_MIX
        ),
        FogColor.a
    );

    /*
     * The texture is used as an alpha mask.
     * RGB comes from FogColor mixed with white.
     */
    vec4 color = vec4(
        particleFogColor.rgb,
        textureColor.a *
        vertexColor.a *
        ColorModulator.a
    );

    if (color.a < AlphaCutoff) {
        discard;
    }

    fragColor = linear_fog(
        color,
        vertexDistance,
        FogStart,
        FogEnd,
        particleFogColor
    );
}
