#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D InDepth;
uniform sampler2D CloudSampler;

uniform mat4 PolyProjMat;
uniform mat4 PolyModelViewMat;
uniform float PolySunAngle;

// Expression uniforms from polytone/post_chains/fake_clouds.json.
uniform float CameraXMod;
uniform float CameraY;
uniform float CameraZMod;
uniform float CloudMotion;
uniform float RainStrength;

in vec2 texCoord;
out vec4 fragColor;

// ======================================================
// Cloud geometry configuration
// ======================================================

// The supplied 256 x 256 texture follows the vanilla cloud grid:
// one texture pixel = one 12 x 12 block cloud cell.
const float CLOUD_CELL_SIZE = 12.0;
const float CLOUD_MAP_SIZE = 256.0;
const float CLOUD_REPEAT = CLOUD_CELL_SIZE * CLOUD_MAP_SIZE;

// Vanilla cloud level 192 + CLOUD_Y_OFFSET 10 from the reference shader.
const float CLOUD_BOTTOM = 202.0;

// Vanilla cloud cells are 4 blocks tall. The reference shader multiplies
// CellSize.y by CLOUD_HEIGHT 1.5, resulting in a 6 block tall box.
const float CLOUD_THICKNESS = 6.0;

const float BOTTOM_ALPHA = 0.6;
const float TOP_ALPHA = 0.0;

// Clouds smoothly disappear as rain strengthens and are fully invisible
// once RainStrength reaches RAIN_FADE_END.
const float RAIN_FADE_START = 0.0;
const float RAIN_FADE_END = 0.5;

// These match the reference shader and can be changed independently later.
const float SHADE_TOP = 1.0;
const float SHADE_BOTTOM = 1.0;
const float SHADE_NORTH = 1.0;
const float SHADE_SOUTH = 1.0;
const float SHADE_WEST = 1.0;
const float SHADE_EAST = 1.0;

const float TRACE_DISTANCE = 1536.0;
const float FADE_START = 400.0;
const float FADE_END = 1400.0;

// The ray only traverses cells while it is inside the six-block cloud slab.
// A deliberately short traversal, matching the tuned version supplied by the
// pack author. Increase this if distant clouds disappear at shallow angles.
const int MAX_DDA_STEPS = 3;
const float RAY_EPSILON = 0.002;
const float HUGE_T = 1.0e20;

// ======================================================
// Camera and depth helpers
// ======================================================

vec3 relativePositionFromDepth(float depth, mat4 invProj, mat4 invView) {
    vec4 ndc = vec4(texCoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 viewPos = invProj * ndc;
    viewPos /= viewPos.w;
    return (invView * vec4(viewPos.xyz, 1.0)).xyz;
}

// ======================================================
// Virtual voxel geometry
// ======================================================

bool cloudCellOccupied(ivec2 cell) {
    // Sample the exact center of the corresponding texture pixel. Polytone
    // supplies repeat wrapping, so negative and >256 cell indices are valid.
    vec2 uv = (vec2(cell) + vec2(0.5)) / CLOUD_MAP_SIZE;
    return texture(CloudSampler, uv).r >= 0.5;
}

vec3 slabEntryNormal(vec3 rayDir) {
    return rayDir.y > 0.0
        ? vec3(0.0, -1.0, 0.0)
        : vec3(0.0, 1.0, 0.0);
}

vec3 slabExitNormal(vec3 rayDir) {
    return rayDir.y > 0.0
        ? vec3(0.0, 1.0, 0.0)
        : vec3(0.0, -1.0, 0.0);
}

// Traverses the 12 x 12 cloud-cell grid only between the two horizontal
// boundaries of the cloud slab. A white texture pixel represents one solid
// box. The function returns exactly one surface: the nearest box face.
bool traceCloudSurface(
    vec3 rayOrigin,
    vec3 rayDir,
    float layerEnter,
    float layerExit,
    float visibleExit,
    out float hitT,
    out vec3 hitNormal
) {
    // Work in a wrapped cloud-coordinate system to preserve float precision.
    // Adding CloudMotion moves the whole voxel grid continuously along X.
    vec3 cloudRayOrigin = vec3(
        CameraXMod + rayOrigin.x + CloudMotion,
        CameraY + rayOrigin.y,
        CameraZMod + rayOrigin.z
    );

    float currentT = layerEnter;
    vec3 startPoint = cloudRayOrigin + rayDir * (currentT + RAY_EPSILON);
    ivec2 cell = ivec2(floor(startPoint.xz / CLOUD_CELL_SIZE));

    ivec2 cellStep = ivec2(
        rayDir.x > RAY_EPSILON ? 1 : (rayDir.x < -RAY_EPSILON ? -1 : 0),
        rayDir.z > RAY_EPSILON ? 1 : (rayDir.z < -RAY_EPSILON ? -1 : 0)
    );

    float deltaTX = cellStep.x == 0
        ? HUGE_T
        : CLOUD_CELL_SIZE / abs(rayDir.x);
    float deltaTZ = cellStep.y == 0
        ? HUGE_T
        : CLOUD_CELL_SIZE / abs(rayDir.z);

    float boundaryX = cellStep.x > 0
        ? (float(cell.x) + 1.0) * CLOUD_CELL_SIZE
        : float(cell.x) * CLOUD_CELL_SIZE;
    float boundaryZ = cellStep.y > 0
        ? (float(cell.y) + 1.0) * CLOUD_CELL_SIZE
        : float(cell.y) * CLOUD_CELL_SIZE;

    float nextTX = cellStep.x == 0
        ? HUGE_T
        : (boundaryX - cloudRayOrigin.x) / rayDir.x;
    float nextTZ = cellStep.y == 0
        ? HUGE_T
        : (boundaryZ - cloudRayOrigin.z) / rayDir.z;

    // Numerical protection for points starting exactly on a grid boundary.
    if (nextTX <= currentT + RAY_EPSILON) nextTX += deltaTX;
    if (nextTZ <= currentT + RAY_EPSILON) nextTZ += deltaTZ;

    bool cameraInsideLayer = layerEnter <= RAY_EPSILON;
    vec3 entryNormal = slabEntryNormal(rayDir);

    for (int i = 0; i < MAX_DDA_STEPS; ++i) {
        if (currentT > visibleExit) break;

        if (cloudCellOccupied(cell)) {
            // Normally the first occupied cell is entered through either the
            // slab bottom/top or one of the vertical cell faces.
            if (!cameraInsideLayer || currentT > RAY_EPSILON) {
                hitT = currentT;
                hitNormal = entryNormal;
                return true;
            }

            // If the camera starts inside an occupied cloud box, return its
            // nearest EXIT face instead of pretending a surface exists at t=0.
            float exitT = layerExit;
            vec3 exitNormal = slabExitNormal(rayDir);

            if (nextTX < exitT) {
                exitT = nextTX;
                exitNormal = vec3(float(cellStep.x), 0.0, 0.0);
            }
            if (nextTZ < exitT) {
                exitT = nextTZ;
                exitNormal = vec3(0.0, 0.0, float(cellStep.y));
            }

            if (exitT <= visibleExit) {
                hitT = exitT;
                hitNormal = exitNormal;
                return true;
            }
            return false;
        }

        float nextT = min(nextTX, nextTZ);
        if (nextT > visibleExit || nextT > layerExit) break;

        bool crossX = nextTX <= nextTZ + RAY_EPSILON;
        bool crossZ = nextTZ <= nextTX + RAY_EPSILON;

        currentT = nextT;

        if (crossX && crossZ) {
            cell.x += cellStep.x;
            cell.y += cellStep.y;
            nextTX += deltaTX;
            nextTZ += deltaTZ;
            entryNormal = normalize(vec3(
                -float(cellStep.x),
                0.0,
                -float(cellStep.y)
            ));
        } else if (crossX) {
            cell.x += cellStep.x;
            nextTX += deltaTX;
            entryNormal = vec3(-float(cellStep.x), 0.0, 0.0);
        } else {
            cell.y += cellStep.y;
            nextTZ += deltaTZ;
            entryNormal = vec3(0.0, 0.0, -float(cellStep.y));
        }

        // From this point onward a hit is always an entry into a new cell,
        // even when the camera originally started inside the vertical slab.
        cameraInsideLayer = false;
    }

    return false;
}

// ======================================================
// Surface appearance
// ======================================================

float faceBrightness(vec3 normal) {
    if (normal.y > 0.5) return SHADE_TOP;
    if (normal.y < -0.5) return SHADE_BOTTOM;
    if (normal.z < -0.5) return SHADE_NORTH;
    if (normal.z > 0.5) return SHADE_SOUTH;
    if (normal.x < -0.5) return SHADE_WEST;
    return SHADE_EAST;
}

vec3 cloudColor() {
    // The sign is inverted for the 1.21.1 PolySunAngle orientation.
    float sunHeight = clamp(-sin(PolySunAngle), -1.0, 1.0);
    float daylight = smoothstep(-0.12, 0.18, sunHeight);
    float horizon = 1.0 - smoothstep(0.06, 0.55, abs(sunHeight));

    vec3 nightColor = vec3(0.0118, 0.0353, 0.0824);
    vec3 dayColor = vec3(0.96, 0.98, 1.0);
    vec3 sunsetColor = vec3(1.0, 0.68, 0.48);

    vec3 color = mix(nightColor, dayColor, daylight);
    color = mix(color, sunsetColor, horizon * daylight * 0.38);

    return color;
}

// ======================================================
// Main
// ======================================================

void main() {
    vec4 scene = texture(DiffuseSampler, texCoord);

    mat4 invProj = inverse(PolyProjMat);
    mat4 invView = inverse(PolyModelViewMat);

    vec3 rayOrigin = (invView * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
    vec4 farView = invProj * vec4(texCoord * 2.0 - 1.0, 1.0, 1.0);
    farView /= farView.w;
    vec3 farRelative = (invView * vec4(farView.xyz, 1.0)).xyz;
    vec3 rayDir = normalize(farRelative - rayOrigin);

    // Avoid effectively infinite traversal directly along the horizon.
    if (abs(rayDir.y) < 0.001) {
        fragColor = scene;
        return;
    }

    float layerBottom = CLOUD_BOTTOM - CameraY;
    float layerTop = layerBottom + CLOUD_THICKNESS;
    float t0 = (layerBottom - rayOrigin.y) / rayDir.y;
    float t1 = (layerTop - rayOrigin.y) / rayDir.y;

    float layerEnter = max(min(t0, t1), 0.0);
    float layerExit = max(t0, t1);
    float visibleExit = min(layerExit, TRACE_DISTANCE);

    // Opaque terrain and the held item terminate the cloud ray.
    float sceneDepth = texture(InDepth, texCoord).r;
    if (sceneDepth < 0.999999) {
        vec3 sceneRelative = relativePositionFromDepth(sceneDepth, invProj, invView);
        float sceneT = dot(sceneRelative - rayOrigin, rayDir);
        visibleExit = min(visibleExit, sceneT - 0.05);
    }

    if (visibleExit <= layerEnter) {
        fragColor = scene;
        return;
    }

    float hitT;
    vec3 hitNormal;
    if (!traceCloudSurface(
        rayOrigin,
        rayDir,
        layerEnter,
        layerExit,
        visibleExit,
        hitT,
        hitNormal
    )) {
        fragColor = scene;
        return;
    }

    vec3 hitRelative = rayOrigin + rayDir * hitT;
    float hitWorldY = CameraY + hitRelative.y;
    float heightPart = clamp(
        (hitWorldY - CLOUD_BOTTOM) / CLOUD_THICKNESS,
        0.0,
        1.0
    );

    // Same behavior as the reference vertex shader: whichever horizontal
    // side faces the camera starts at BOTTOM_ALPHA, the opposite side is zero.
    bool cameraBelow = CameraY <= CLOUD_BOTTOM + CLOUD_THICKNESS * 0.5;
    float gradientPart = cameraBelow ? heightPart : 1.0 - heightPart;
    float alpha = mix(BOTTOM_ALPHA, TOP_ALPHA, gradientPart);

    float angleFade = smoothstep(0.001, 0.010, abs(rayDir.y));
    float distanceFade = 1.0 - smoothstep(FADE_START, FADE_END, hitT);
    float rain = clamp(RainStrength, 0.0, 1.0);
    float rainVisibility = 1.0 - smoothstep(
        RAIN_FADE_START,
        RAIN_FADE_END,
        rain
    );
    alpha *= angleFade * distanceFade * rainVisibility;

    if (alpha <= 0.0001) {
        fragColor = scene;
        return;
    }

    vec3 surfaceColor = cloudColor() * faceBrightness(hitNormal);
    fragColor = vec4(mix(scene.rgb, surfaceColor, alpha), scene.a);
}
